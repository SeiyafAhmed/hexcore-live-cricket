from PySide6.QtWidgets import QWidget, QVBoxLayout, QCheckBox
from PySide6.QtCore import QSettings

class SettingsTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.settings = QSettings("Hexcore", "CricketScorer")
        
        layout = QVBoxLayout(self)
        
        self.wagon_wheel_cb = QCheckBox("Enable Wagon Wheel Input")
        # Load saved setting, default to False
        is_enabled = self.settings.value("enable_wagon_wheel", "false") == "true"
        self.wagon_wheel_cb.setChecked(is_enabled)
        
        self.wagon_wheel_cb.toggled.connect(self.save_settings)
        
        layout.addWidget(self.wagon_wheel_cb)
        layout.addStretch()

    def save_settings(self, checked):
        self.settings.setValue("enable_wagon_wheel", "true" if checked else "false")
