import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QColorDialog, QFileDialog, QComboBox, QSpinBox, QMessageBox,
    QListWidget, QListWidgetItem, QTabWidget, QGroupBox, QFormLayout, QAbstractItemView
)
from PySide6.QtGui import QColor
from PySide6.QtCore import Qt

import api

class PreMatchSetup(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pre-Match Setup")
        
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        
        self.setup_team_tab()
        self.setup_player_tab()
        
    def setup_team_tab(self):
        tab = QWidget()
        layout = QFormLayout(tab)
        
        self.team_name_input = QLineEdit()
        self.team_color_btn = QPushButton("Select Color (#000000)")
        self.team_color_hex = "#000000"
        self.team_color_btn.clicked.connect(self.select_team_color)
        
        self.team_logo_btn = QPushButton("Select Logo")
        self.team_logo_path = None
        self.team_logo_btn.clicked.connect(self.select_team_logo)
        
        save_btn = QPushButton("Create Team")
        save_btn.clicked.connect(self.create_team)
        
        layout.addRow("Team Name:", self.team_name_input)
        layout.addRow("Theme Color:", self.team_color_btn)
        layout.addRow("Logo:", self.team_logo_btn)
        layout.addRow("", save_btn)
        
        self.tabs.addTab(tab, "Create Team")
        
    def select_team_color(self):
        color = QColorDialog.getColor(QColor(self.team_color_hex), self, "Select Theme Color")
        if color.isValid():
            self.team_color_hex = color.name()
            self.team_color_btn.setText(f"Select Color ({self.team_color_hex})")
            self.team_color_btn.setStyleSheet(f"background-color: {self.team_color_hex}; color: {'white' if color.lightness() < 128 else 'black'};")

    def select_team_logo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Team Logo", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self.team_logo_path = path
            self.team_logo_btn.setText(os.path.basename(path))

    def create_team(self):
        name = self.team_name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Team name is required.")
            return
            
        try:
            api.create_team(name, self.team_color_hex, self.team_logo_path)
            QMessageBox.information(self, "Success", f"Team '{name}' created successfully!")
            self.team_name_input.clear()
            self.team_logo_path = None
            self.team_logo_btn.setText("Select Logo")
            self.refresh_teams()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create team: {e}")

    def setup_player_tab(self):
        tab = QWidget()
        layout = QFormLayout(tab)
        
        self.player_first_name = QLineEdit()
        self.player_last_name = QLineEdit()
        
        self.player_jersey = QSpinBox()
        self.player_jersey.setRange(0, 999)
        
        self.player_role = QComboBox()
        self.player_role.addItem("Batsman", "BAT")
        self.player_role.addItem("Bowler", "BOWL")
        self.player_role.addItem("All-Rounder", "AR")
        self.player_role.addItem("Wicket Keeper", "WK")
        
        self.player_team = QComboBox()
        
        self.player_image_btn = QPushButton("Select Headshot")
        self.player_image_path = None
        self.player_image_btn.clicked.connect(self.select_player_image)
        
        save_btn = QPushButton("Create Player")
        save_btn.clicked.connect(self.create_player)
        
        refresh_teams_btn = QPushButton("Refresh Teams")
        refresh_teams_btn.clicked.connect(self.refresh_teams)
        
        layout.addRow("First Name:", self.player_first_name)
        layout.addRow("Last Name:", self.player_last_name)
        layout.addRow("Jersey Number:", self.player_jersey)
        layout.addRow("Role:", self.player_role)
        
        team_layout = QHBoxLayout()
        team_layout.addWidget(self.player_team)
        team_layout.addWidget(refresh_teams_btn)
        layout.addRow("Team:", team_layout)
        
        layout.addRow("Headshot:", self.player_image_btn)
        layout.addRow("", save_btn)
        
        self.tabs.addTab(tab, "Create Player")

    def select_player_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Player Headshot", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self.player_image_path = path
            self.player_image_btn.setText(os.path.basename(path))

    def create_player(self):
        first_name = self.player_first_name.text().strip()
        last_name = self.player_last_name.text().strip()
        jersey = self.player_jersey.value()
        role = self.player_role.currentData()
        team_id = self.player_team.currentData()
        
        if not first_name or not last_name or not team_id:
            QMessageBox.warning(self, "Error", "First name, last name, and team are required.")
            return
            
        try:
            api.create_player(first_name, last_name, jersey, role, team_id, self.player_image_path)
            QMessageBox.information(self, "Success", f"Player '{first_name} {last_name}' created successfully!")
            self.player_first_name.clear()
            self.player_last_name.clear()
            self.player_image_path = None
            self.player_image_btn.setText("Select Headshot")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create player: {e}")

    def refresh_teams(self):
        try:
            # We assume pagination returns a 'results' key if page size is configured
            response = api.get_teams()
            teams = response.get('results', response) if isinstance(response, dict) else response
            
            self.player_team.clear()
            
            for team in teams:
                self.player_team.addItem(team["name"], team["id"])
        except Exception as e:
            print(f"Failed to refresh teams: {e}")

    def setup_playing_xi_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("Select Team:"))
        self.xi_team_combo = QComboBox()
        self.xi_team_combo.currentIndexChanged.connect(self.load_team_players)
        top_layout.addWidget(self.xi_team_combo)
        
        refresh_xi_btn = QPushButton("Refresh Team Data")
        refresh_xi_btn.clicked.connect(self.refresh_teams)
        top_layout.addWidget(refresh_xi_btn)
        
        layout.addLayout(top_layout)
        
        lists_layout = QHBoxLayout()
        
        # Available players
        avail_group = QGroupBox("Available Players")
        avail_layout = QVBoxLayout(avail_group)
        self.list_available = QListWidget()
        self.list_available.setSelectionMode(QAbstractItemView.ExtendedSelection)
        avail_layout.addWidget(self.list_available)
        lists_layout.addWidget(avail_group)
        
        # Transfer buttons
        btn_layout = QVBoxLayout()
        btn_layout.addStretch()
        self.btn_add = QPushButton(">>")
        self.btn_add.clicked.connect(self.add_to_xi)
        btn_layout.addWidget(self.btn_add)
        
        self.btn_remove = QPushButton("<<")
        self.btn_remove.clicked.connect(self.remove_from_xi)
        btn_layout.addWidget(self.btn_remove)
        btn_layout.addStretch()
        lists_layout.addLayout(btn_layout)
        
        # Playing XI
        xi_group = QGroupBox("Playing XI (Max 11)")
        xi_layout = QVBoxLayout(xi_group)
        self.list_xi = QListWidget()
        self.list_xi.setSelectionMode(QAbstractItemView.ExtendedSelection)
        xi_layout.addWidget(self.list_xi)
        lists_layout.addWidget(xi_group)
        
        layout.addLayout(lists_layout)
        
        save_xi_btn = QPushButton("Save Playing XI (Local)")
        save_xi_btn.clicked.connect(self.save_playing_xi)
        layout.addWidget(save_xi_btn)
        
        self.tabs.addTab(tab, "Playing XI Setup")

    def load_team_players(self):
        team_id = self.xi_team_combo.currentData()
        if not team_id:
            return
            
        self.list_available.clear()
        self.list_xi.clear()
        
        try:
            response = api.get_players(team_id)
            players = response.get('results', response) if isinstance(response, dict) else response
            
            for p in players:
                item = QListWidgetItem(f"{p['full_name']} (#{p['jersey_number']})")
                item.setData(Qt.UserRole, p['id'])
                self.list_available.addItem(item)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load players: {e}")

    def add_to_xi(self):
        selected_items = self.list_available.selectedItems()
        for item in selected_items:
            if self.list_xi.count() >= 11:
                QMessageBox.warning(self, "Limit Reached", "Playing XI cannot have more than 11 players.")
                break
            # Move item
            row = self.list_available.row(item)
            self.list_available.takeItem(row)
            self.list_xi.addItem(item)

    def remove_from_xi(self):
        selected_items = self.list_xi.selectedItems()
        for item in selected_items:
            # Move item
            row = self.list_xi.row(item)
            self.list_xi.takeItem(row)
            self.list_available.addItem(item)
            
    def save_playing_xi(self):
        xi_players = []
        for i in range(self.list_xi.count()):
            item = self.list_xi.item(i)
            xi_players.append({
                "id": item.data(Qt.UserRole),
                "name": item.text()
            })
            
        team_name = self.xi_team_combo.currentText()
        # In a real app, you might POST this to a Match endpoint.
        # For now, we'll just show it was captured.
        QMessageBox.information(self, "Playing XI Saved", f"Saved {len(xi_players)} players for {team_name} (local memory).")

