import math
import copy
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton, QLabel,
    QMenu, QMessageBox, QDialog, QFormLayout, QComboBox, QLineEdit, QSpinBox,
    QGraphicsView, QGraphicsScene, QToolBar, QGroupBox, QScrollArea, QFrame,
    QSizePolicy, QCheckBox
)
from PySide6.QtCore import Qt, QSettings
from PySide6.QtGui import QPen, QBrush, QColor, QMouseEvent, QFont
from ws_client import ws_manager

import api
from PySide6.QtWidgets import QStackedWidget

class MatchSetupScreen(QWidget):
    def __init__(self, main_tab, parent=None):
        super().__init__(parent)
        self.main_tab = main_tab
        
        layout = QFormLayout(self)
        
        self.overs_spin = QSpinBox()
        self.overs_spin.setValue(20)
        self.overs_spin.setRange(1, 100)
        
        self.balls_spin = QSpinBox()
        self.balls_spin.setValue(6)
        self.balls_spin.setRange(1, 12)
        
        self.batting_team_combo = QComboBox()
        self.bowling_team_combo = QComboBox()
        self.toss_combo = QComboBox()
        self.decision_combo = QComboBox()
        self.decision_combo.addItems(["Batting", "Bowling"])
        
        self.striker_combo = QComboBox()
        self.non_striker_combo = QComboBox()
        self.bowler_combo = QComboBox()
        
        self.batting_team_combo.currentIndexChanged.connect(self.update_toss)
        self.bowling_team_combo.currentIndexChanged.connect(self.update_toss)
        self.batting_team_combo.currentIndexChanged.connect(self.update_players_dropdowns)
        self.bowling_team_combo.currentIndexChanged.connect(self.update_players_dropdowns)
        self.toss_combo.currentIndexChanged.connect(self.update_players_dropdowns)
        self.decision_combo.currentIndexChanged.connect(self.update_players_dropdowns)
        
        layout.addRow("No. of Overs:", self.overs_spin)
        layout.addRow("Balls per Over:", self.balls_spin)
        layout.addRow("Team 1:", self.batting_team_combo)
        layout.addRow("Team 2:", self.bowling_team_combo)
        layout.addRow("Toss Won By:", self.toss_combo)
        layout.addRow("Decision:", self.decision_combo)
        layout.addRow("Opening Striker:", self.striker_combo)
        layout.addRow("Opening Non-Striker:", self.non_striker_combo)
        layout.addRow("Opening Bowler:", self.bowler_combo)
        
        self.submit_btn = QPushButton("Start Innings")
        self.submit_btn.setStyleSheet("background-color: #2E7D32; color: white; padding: 10px; font-weight: bold; font-size: 16px;")
        self.submit_btn.clicked.connect(self.start_innings)
        layout.addRow("", self.submit_btn)
        
        self.refresh_data()
        
    def refresh_data(self):
        self.batting_team_combo.clear()
        self.bowling_team_combo.clear()
        try:
            teams = api.get_teams()
            for t in teams:
                self.batting_team_combo.addItem(t['name'], t['id'])
                self.bowling_team_combo.addItem(t['name'], t['id'])
            if len(teams) >= 2:
                self.bowling_team_combo.setCurrentIndex(1)
        except Exception:
            self.batting_team_combo.addItems(["Team A", "Team B"])
            self.bowling_team_combo.addItems(["Team A", "Team B"])
            self.bowling_team_combo.setCurrentIndex(1)
            
    def update_toss(self):
        self.toss_combo.clear()
        if self.batting_team_combo.currentText():
            self.toss_combo.addItem(self.batting_team_combo.currentText())
        if self.bowling_team_combo.currentText() and self.bowling_team_combo.currentText() != self.batting_team_combo.currentText():
            self.toss_combo.addItem(self.bowling_team_combo.currentText())

    def update_players_dropdowns(self, *args):
        team1_id = self.batting_team_combo.currentData()
        team2_id = self.bowling_team_combo.currentData()
        team1_name = self.batting_team_combo.currentText()
        team2_name = self.bowling_team_combo.currentText()
        
        toss_winner = self.toss_combo.currentText()
        decision = self.decision_combo.currentText()
        
        batting_id = team1_id
        bowling_id = team2_id
        
        if toss_winner and decision:
            if toss_winner == team1_name:
                if decision == "Bowling":
                    batting_id, bowling_id = team2_id, team1_id
            elif toss_winner == team2_name:
                if decision == "Batting":
                    batting_id, bowling_id = team2_id, team1_id
                    
        self.striker_combo.clear()
        self.non_striker_combo.clear()
        if batting_id:
            try:
                players = api.get_players(batting_id)
                for p in players:
                    name = f"{p['first_name']} {p['last_name']}"
                    self.striker_combo.addItem(name)
                    self.non_striker_combo.addItem(name)
                if len(players) > 1:
                    self.non_striker_combo.setCurrentIndex(1)
            except: pass
                
        if self.striker_combo.count() == 0:
            for i in range(1, 12):
                self.striker_combo.addItem(f"Batsman {i}")
                self.non_striker_combo.addItem(f"Batsman {i}")
            self.non_striker_combo.setCurrentIndex(1)
            
        self.bowler_combo.clear()
        if bowling_id:
            try:
                players = api.get_players(bowling_id)
                for p in players:
                    self.bowler_combo.addItem(f"{p['first_name']} {p['last_name']}")
            except: pass
                
        if self.bowler_combo.count() == 0:
            for i in range(1, 12):
                self.bowler_combo.addItem(f"Bowler {i}")
                
        self.actual_bowling_team_id = bowling_id

    def start_innings(self):
        team1 = self.batting_team_combo.currentText()
        team2 = self.bowling_team_combo.currentText()
        striker = self.striker_combo.currentText()
        non_striker = self.non_striker_combo.currentText()
        bowler = self.bowler_combo.currentText()
        
        if not team1 or not team2:
            QMessageBox.warning(self, "Validation Error", "Please select both teams.")
            return
            
        if team1 == team2:
            QMessageBox.warning(self, "Validation Error", "Team 1 and Team 2 cannot be the same.")
            return
            
        if not striker or not non_striker:
            QMessageBox.warning(self, "Validation Error", "Please select both opening batsmen.")
            return
            
        if striker == non_striker:
            QMessageBox.warning(self, "Validation Error", "Striker and Non-Striker cannot be the same player.")
            return
            
        if not bowler:
            QMessageBox.warning(self, "Validation Error", "Please select an opening bowler.")
            return

        innings = self.main_tab.state.get("innings", 1)
        target = self.main_tab.state.get("target", None)
        
        if innings == 1:
            self.main_tab.state["team_1_name"] = team1
            self.main_tab.state["team_2_name"] = team2
        
        self.main_tab.state.update({
            "innings": innings,
            "target": target,
            "max_overs": self.overs_spin.value(),
            "balls_per_over": self.balls_spin.value(),
            "toss_winner": self.toss_combo.currentText(),
            "decision": self.decision_combo.currentText(),
            "striker": {"name": striker, "runs": 0, "balls": 0, "4s": 0, "6s": 0, "status": "not out"},
            "non_striker": {"name": non_striker, "runs": 0, "balls": 0, "4s": 0, "6s": 0, "status": "not out"},
            "bowler": {"name": bowler, "runs": 0, "overs": 0.0, "wickets": 0, "maidens": 0},
            "runs": 0, "wickets": 0, "overs_completed": 0, "balls_this_over": 0,
            "this_over": [], "past_overs": [], "previous_bowler": None,
            "out_batsmen": [],
            "batsmen_stats": {},
            "bowler_stats": {},
            "extras": {"wd": 0, "nb": 0, "b": 0, "lb": 0},
            "bowling_team_id": getattr(self, 'actual_bowling_team_id', self.bowling_team_combo.currentData())
        })
        self.main_tab.state["batsmen_stats"][striker] = self.main_tab.state["striker"].copy()
        self.main_tab.state["batsmen_stats"][non_striker] = self.main_tab.state["non_striker"].copy()
        self.main_tab.state["bowler_stats"][bowler] = self.main_tab.state["bowler"].copy()
        
        self.main_tab.history_stack.clear()
        self.main_tab.init_scoring_ui()
        self.main_tab.stacked.setCurrentIndex(1)
        self.main_tab.update_ui()

class NewOverDialog(QDialog):
    def __init__(self, previous_bowler, bowling_team_id=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Next Bowler")
        layout = QFormLayout(self)
        self.bowler_combo = QComboBox()
        
        players = []
        if bowling_team_id:
            try:
                for p in api.get_players(bowling_team_id):
                    players.append(f"{p['first_name']} {p['last_name']}")
            except: pass
            
        if not players:
            players = [f"Bowler {i}" for i in range(1, 12)]
            
        for name in players:
            if name != previous_bowler:
                self.bowler_combo.addItem(name)
                
        layout.addRow("Next Bowler:", self.bowler_combo)
        self.submit_btn = QPushButton("Start Over")
        self.submit_btn.clicked.connect(self.accept)
        layout.addRow("", self.submit_btn)

class WicketDialog(QDialog):
    def __init__(self, current_striker, current_non_striker, out_batsmen, batting_team_id, bowling_team_id, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Wicket Details")
        
        layout = QVBoxLayout(self)
        form = QFormLayout()
        
        self.method_combo = QComboBox()
        self.method_combo.addItems([
            "Bowled", "Caught", "Stumped", "LBW", "Run Out", 
            "Mankad", "Retired", "Hit Wicket"
        ])
        
        self.fielder_combo = QComboBox()
        self.keeper_combo = QComboBox()
        
        bowling_players = []
        if bowling_team_id:
            try:
                for p in api.get_players(bowling_team_id):
                    bowling_players.append(f"{p['first_name']} {p['last_name']}")
            except: pass
            
        if not bowling_players:
            bowling_players = [f"Fielder {i}" for i in range(1, 12)]
            
        self.fielder_combo.addItems(bowling_players)
        self.keeper_combo.addItems(bowling_players)
        
        self.is_wide_cb = QCheckBox("Is Wide?")
        
        self.ro_batsman_combo = QComboBox()
        self.ro_batsman_combo.addItems([current_striker, current_non_striker])
        
        self.ro_runs_combo = QComboBox()
        self.ro_runs_combo.addItems([str(i) for i in range(8)])
        
        self.ro_extra_combo = QComboBox()
        self.ro_extra_combo.addItems(["None", "Byes", "Leg Byes"])
        
        self.ro_illegal_combo = QComboBox()
        self.ro_illegal_combo.addItems(["None", "No Ball", "Wide"])
        
        self.new_batsman_combo = QComboBox()
        batting_players = []
        if batting_team_id:
            try:
                for p in api.get_players(batting_team_id):
                    name = f"{p['first_name']} {p['last_name']}"
                    if name != current_striker and name != current_non_striker and name not in out_batsmen:
                        batting_players.append(name)
            except: pass
        if not batting_players:
            batting_players = [f"Batsman {i}" for i in range(3, 12)]
        self.new_batsman_combo.addItems(batting_players)
        
        form.addRow("Method:", self.method_combo)
        
        self.fielder_lbl = QLabel("Fielder:")
        form.addRow(self.fielder_lbl, self.fielder_combo)
        
        self.keeper_lbl = QLabel("Keeper:")
        form.addRow(self.keeper_lbl, self.keeper_combo)
        
        form.addRow("", self.is_wide_cb)
        
        self.ro_bat_lbl = QLabel("Batsman Out:")
        form.addRow(self.ro_bat_lbl, self.ro_batsman_combo)
        
        self.ro_runs_lbl = QLabel("Completed Runs:")
        form.addRow(self.ro_runs_lbl, self.ro_runs_combo)
        
        self.ro_ill_lbl = QLabel("No Ball/Wide:")
        form.addRow(self.ro_ill_lbl, self.ro_illegal_combo)
        
        self.ro_ext_lbl = QLabel("Byes/Leg Byes:")
        form.addRow(self.ro_ext_lbl, self.ro_extra_combo)
        
        form.addRow("New Batsman:", self.new_batsman_combo)
        
        layout.addLayout(form)
        
        self.submit_btn = QPushButton("Confirm Wicket")
        self.submit_btn.clicked.connect(self.accept)
        layout.addWidget(self.submit_btn)
        
        self.method_combo.currentTextChanged.connect(self.update_visibility)
        self.ro_illegal_combo.currentTextChanged.connect(self.update_extra_options)
        self.update_visibility()
        self.update_extra_options(self.ro_illegal_combo.currentText())
        
    def update_extra_options(self, text):
        if text == "Wide":
            self.ro_extra_combo.setCurrentText("None")
            self.ro_extra_combo.setEnabled(False)
        else:
            self.ro_extra_combo.setEnabled(True)
            
    def update_visibility(self):
        method = self.method_combo.currentText()
        
        self.fielder_lbl.hide()
        self.fielder_combo.hide()
        self.keeper_lbl.hide()
        self.keeper_combo.hide()
        self.is_wide_cb.hide()
        
        self.ro_bat_lbl.hide()
        self.ro_batsman_combo.hide()
        self.ro_runs_lbl.hide()
        self.ro_runs_combo.hide()
        self.ro_ext_lbl.hide()
        self.ro_extra_combo.hide()
        self.ro_ill_lbl.hide()
        self.ro_illegal_combo.hide()
        
        if method == "Caught":
            self.fielder_lbl.show()
            self.fielder_combo.show()
        elif method == "Stumped":
            self.keeper_lbl.show()
            self.keeper_combo.show()
            self.is_wide_cb.show()
        elif method == "Run Out":
            self.fielder_lbl.show()
            self.fielder_combo.show()
            self.ro_bat_lbl.show()
            self.ro_batsman_combo.show()
            self.ro_runs_lbl.show()
            self.ro_runs_combo.show()
            self.ro_ext_lbl.show()
            self.ro_extra_combo.show()
            self.ro_ill_lbl.show()
            self.ro_illegal_combo.show()
        elif method == "Hit Wicket":
            self.is_wide_cb.show()

class LiveScoringTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = QSettings("Hexcore", "CricketScorer")
        
        self.setStyleSheet("""
            LiveScoringTab { background-color: white; color: black; }
            QGroupBox { color: black; font-weight: bold; border: 1px solid gray; border-radius: 5px; margin-top: 1ex; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }
            QScrollArea { border: 1px solid #ccc; background-color: white; }
            QLabel { color: black; }
        """)
        
        self.history_stack = []
        
        self.state = {
            "runs": 0, "wickets": 0, "overs_completed": 0, "balls_this_over": 0,
            "max_overs": 20, "balls_per_over": 6,
            "striker": {"name": "Player 1", "runs": 0, "balls": 0},
            "non_striker": {"name": "Player 2", "runs": 0, "balls": 0},
            "bowler": {"name": "Bowler 4", "runs": 0, "overs": 0.0, "wickets": 0},
            "previous_bowler": None, "this_over": [], "past_overs": [],
            "theme_color": "#1A2B3C", "bowling_team_id": None
        }
        
        main_layout = QVBoxLayout(self)
        self.stacked = QStackedWidget()
        
        self.setup_screen = MatchSetupScreen(self)
        self.stacked.addWidget(self.setup_screen)
        
        self.scoring_widget = QWidget()
        self.scoring_layout = QVBoxLayout(self.scoring_widget)
        self.stacked.addWidget(self.scoring_widget)
        
        main_layout.addWidget(self.stacked)
        
    def init_scoring_ui(self):
        # Clear existing
        if self.scoring_layout.itemAt(0) is not None:
            while self.scoring_layout.count():
                item = self.scoring_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
                elif item.layout():
                    pass

        main_split = QHBoxLayout()
        
        # ================= LEFT PANEL =================
        left_panel = QWidget()
        left_panel.setStyleSheet("background-color: white; color: black;")
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(10)
        
        # --- Top Scoreboard ---
        top_score_widget = QWidget()
        ts_layout = QGridLayout(top_score_widget)
        
        t1_name = self.state.get("team_1_name", self.setup_screen.batting_team_combo.currentText())
        t2_name = self.state.get("team_2_name", self.setup_screen.bowling_team_combo.currentText())
        
        self.lbl_team1_name = QLabel(t1_name)
        self.lbl_team1_name.setFont(QFont("Arial", 14, QFont.Bold))
        
        i1_stats = self.state.get("innings_1_stats")
        if i1_stats:
            self.lbl_team1_score = QLabel(f"{i1_stats['runs']}/{i1_stats['wickets']}")
            self.lbl_team1_overs = QLabel(f"({i1_stats['overs_completed']}.{i1_stats['balls_this_over']})")
        else:
            self.lbl_team1_score = QLabel("0/0")
            self.lbl_team1_overs = QLabel("(0.0)")
            
        self.lbl_team1_score.setFont(QFont("Arial", 24, QFont.Bold))
        
        lbl_vs = QLabel("VS")
        lbl_vs.setAlignment(Qt.AlignCenter)
        
        self.lbl_team2_name = QLabel(t2_name)
        self.lbl_team2_name.setFont(QFont("Arial", 14, QFont.Bold))
        self.lbl_team2_score = QLabel("0/0")
        self.lbl_team2_score.setFont(QFont("Arial", 24, QFont.Bold))
        self.lbl_team2_overs = QLabel("(0.0)")
        
        ts_layout.addWidget(self.lbl_team1_score, 0, 0, Qt.AlignLeft)
        ts_layout.addWidget(self.lbl_team1_overs, 1, 0, Qt.AlignLeft)
        ts_layout.addWidget(self.lbl_team1_name, 2, 0, Qt.AlignLeft)
        
        ts_layout.addWidget(lbl_vs, 0, 1, 3, 1, Qt.AlignCenter)
        
        ts_layout.addWidget(self.lbl_team2_score, 0, 2, Qt.AlignRight)
        ts_layout.addWidget(self.lbl_team2_overs, 1, 2, Qt.AlignRight)
        ts_layout.addWidget(self.lbl_team2_name, 2, 2, Qt.AlignRight)
        
        info_layout = QHBoxLayout()
        self.lbl_target = QLabel("Target: -")
        self.lbl_target.setStyleSheet("color: black;")
        self.lbl_rr = QLabel("RR: 0.00")
        self.lbl_rr.setStyleSheet("color: black;")
        self.lbl_rrr = QLabel("RRR: -")
        self.lbl_rrr.setStyleSheet("color: black;")
        info_layout.addWidget(self.lbl_target)
        info_layout.addStretch()
        info_layout.addWidget(self.lbl_rr)
        info_layout.addStretch()
        info_layout.addWidget(self.lbl_rrr)
        
        left_layout.addWidget(top_score_widget)
        left_layout.addLayout(info_layout)
        
        sep1 = QFrame()
        sep1.setFrameShape(QFrame.HLine)
        sep1.setStyleSheet("background-color: gray;")
        left_layout.addWidget(sep1)
        
        # --- Active Players ---
        self.striker_widget = QWidget()
        self.striker_widget.setStyleSheet("background-color: #2E7D32; color: white; padding: 5px;")
        s_lay = QHBoxLayout(self.striker_widget)
        s_lay.setContentsMargins(5, 5, 5, 5)
        self.lbl_striker_name = QLabel("Batsman 1 *")
        self.lbl_striker_name.setStyleSheet("color: white;")
        self.lbl_striker_name.setFont(QFont("Arial", 12, QFont.Bold))
        self.lbl_striker_score = QLabel("0 (0)")
        self.lbl_striker_score.setStyleSheet("color: white;")
        self.lbl_striker_score.setFont(QFont("Arial", 12, QFont.Bold))
        
        swap_btn = QPushButton("↑↓")
        swap_btn.setFixedSize(30, 25)
        swap_btn.setStyleSheet("background-color: white; color: black; font-weight: bold; border-radius: 4px;")
        swap_btn.clicked.connect(self.swap_batsmen)
        
        s_lay.addWidget(self.lbl_striker_name)
        s_lay.addStretch()
        s_lay.addWidget(swap_btn)
        s_lay.addWidget(self.lbl_striker_score)
        
        self.non_striker_widget = QWidget()
        self.non_striker_widget.setStyleSheet("background-color: #D3D3D3; color: black; padding: 5px;")
        ns_lay = QHBoxLayout(self.non_striker_widget)
        ns_lay.setContentsMargins(5, 5, 5, 5)
        self.lbl_non_striker_name = QLabel("Batsman 2")
        self.lbl_non_striker_name.setStyleSheet("color: black;")
        self.lbl_non_striker_name.setFont(QFont("Arial", 12))
        self.lbl_non_striker_score = QLabel("0 (0)")
        self.lbl_non_striker_score.setStyleSheet("color: black;")
        self.lbl_non_striker_score.setFont(QFont("Arial", 12))
        ns_lay.addWidget(self.lbl_non_striker_name)
        ns_lay.addStretch()
        ns_lay.addWidget(self.lbl_non_striker_score)
        
        self.extras_widget = QWidget()
        self.extras_widget.setStyleSheet("background-color: #C8E6C9; color: #2E7D32; padding: 5px;")
        ext_lay = QHBoxLayout(self.extras_widget)
        ext_lay.setContentsMargins(5, 5, 5, 5)
        lbl_ext = QLabel("Extras")
        lbl_ext.setStyleSheet("color: #2E7D32;")
        lbl_ext.setFont(QFont("Arial", 12, QFont.Bold))
        self.lbl_extras_detail = QLabel("0")
        self.lbl_extras_detail.setStyleSheet("color: #2E7D32;")
        ext_lay.addWidget(lbl_ext)
        ext_lay.addStretch()
        ext_lay.addWidget(self.lbl_extras_detail)
        
        self.bowler_widget = QWidget()
        self.bowler_widget.setStyleSheet("background-color: #2E7D32; color: white; padding: 5px;")
        b_lay = QHBoxLayout(self.bowler_widget)
        b_lay.setContentsMargins(5, 5, 5, 5)
        self.lbl_bowler_name = QLabel("Bowler 1")
        self.lbl_bowler_name.setStyleSheet("color: white;")
        self.lbl_bowler_name.setFont(QFont("Arial", 12, QFont.Bold))
        self.lbl_bowler_score = QLabel("0-0 (0.0)")
        self.lbl_bowler_score.setStyleSheet("color: white;")
        self.lbl_bowler_score.setFont(QFont("Arial", 12, QFont.Bold))
        b_lay.addWidget(self.lbl_bowler_name)
        b_lay.addStretch()
        b_lay.addWidget(self.lbl_bowler_score)
        
        left_layout.addWidget(self.striker_widget)
        left_layout.addWidget(self.non_striker_widget)
        left_layout.addWidget(self.extras_widget)
        left_layout.addWidget(self.bowler_widget)
        
        # --- This Over Boxes ---
        self.this_over_flow = QWidget()
        self.mid_layout = QHBoxLayout(self.this_over_flow)
        self.mid_layout.setContentsMargins(0, 5, 0, 5)
        self.mid_layout.setAlignment(Qt.AlignLeft)
        
        self.over_boxes = []
        self.mid_layout.addStretch()
        left_layout.addWidget(self.this_over_flow)
        
        # History
        hist_group = QGroupBox("History")
        self.history_layout = QVBoxLayout(hist_group)
        self.history_layout.setAlignment(Qt.AlignTop)
        
        hist_scroll = QScrollArea()
        hist_scroll.setWidgetResizable(True)
        hist_scroll.setWidget(hist_group)
        hist_scroll.setMaximumHeight(150)
        left_layout.addWidget(hist_scroll)
        
        # --- Admin Control ---
        admin_group = QGroupBox("Admin Control")
        admin_group.setFont(QFont("Arial", 12))
        admin_layout = QVBoxLayout(admin_group)
        
        undo_lay = QHBoxLayout()
        undo_lay.addStretch()
        undo_btn = QPushButton("undo")
        undo_btn.setStyleSheet("background-color: gray; color: white; font-weight: bold; padding: 5px 15px; border-radius: 5px;")
        undo_btn.clicked.connect(self.undo)
        undo_lay.addWidget(undo_btn)
        admin_layout.addLayout(undo_lay)
        
        admin_grid = QGridLayout()
        admin_grid.setSpacing(10)
        
        def create_btn(text, bg, fg="white", func=None):
            b = QPushButton(text)
            b.setFont(QFont("Arial", 16, QFont.Bold))
            b.setStyleSheet(f"background-color: {bg}; color: {fg}; border-radius: 8px; min-height: 50px;")
            if func: b.clicked.connect(func)
            return b
            
        admin_grid.addWidget(create_btn("0", "#0D2C54", func=lambda: self.process_delivery("0", 0, 0, 0, True, 0, False)), 0, 0)
        admin_grid.addWidget(create_btn("1", "#ED7D31", func=lambda: self.process_delivery("1", 1, 1, 1, True, 1, False)), 0, 1)
        admin_grid.addWidget(create_btn("2", "#ED7D31", func=lambda: self.process_delivery("2", 2, 2, 2, True, 2, False)), 0, 2)
        admin_grid.addWidget(create_btn("3", "#ED7D31", func=lambda: self.process_delivery("3", 3, 3, 3, True, 3, False)), 0, 3)
        admin_grid.addWidget(create_btn("4", "#2E7D32", func=lambda: self.process_delivery("4", 4, 4, 4, True, 4, False)), 0, 4)
        admin_grid.addWidget(create_btn("6", "#2E7D32", func=lambda: self.process_delivery("6", 6, 6, 6, True, 6, False)), 0, 5)
        admin_grid.addWidget(create_btn("W", "#D32F2F", func=self.score_wicket), 0, 6)
        
        self.wd_btn = create_btn("Wd", "white", "black")
        self.wd_btn.setStyleSheet("background-color: white; color: black; border: 2px solid black; border-radius: 8px; min-height: 50px;")
        self.wd_btn.clicked.connect(self.show_wd_menu)
        admin_grid.addWidget(self.wd_btn, 1, 0)
        
        self.nb_btn = create_btn("Nb", "#FFC107", "black")
        self.nb_btn.clicked.connect(self.show_nb_menu)
        admin_grid.addWidget(self.nb_btn, 1, 1)
        
        self.byes_btn = create_btn("Byes", "#00BCD4", "black")
        self.byes_btn.clicked.connect(self.show_byes_menu)
        admin_grid.addWidget(self.byes_btn, 1, 2)
        
        self.lb_btn = create_btn("LB", "#00BCD4", "black")
        self.lb_btn.clicked.connect(self.show_lb_menu)
        admin_grid.addWidget(self.lb_btn, 1, 3)
        
        self.more_runs_btn = create_btn("5789", "#ED7D31")
        self.more_runs_btn.clicked.connect(self.show_more_runs_menu)
        admin_grid.addWidget(self.more_runs_btn, 1, 4)
        
        admin_grid.addWidget(create_btn("bonus", "#9C27B0"), 1, 5)
        admin_grid.addWidget(create_btn("More", "black"), 1, 6)
        
        admin_layout.addLayout(admin_grid)
        left_layout.addWidget(admin_group)
        
        reset_btn = QPushButton("End Innings / Start New")
        reset_btn.setStyleSheet("background-color: #dc3545; color: white; padding: 10px; font-weight: bold;")
        reset_btn.clicked.connect(self.end_innings)
        left_layout.addWidget(reset_btn)
        
        
        # ================= RIGHT PANEL =================
        right_panel = QWidget()
        right_panel.setStyleSheet("background-color: white; color: black;")
        self.right_layout = QVBoxLayout(right_panel)
        self.right_layout.setAlignment(Qt.AlignTop)
        
        tabs_lay = QHBoxLayout()
        tab1 = QLabel(self.setup_screen.batting_team_combo.currentText())
        tab1.setStyleSheet("background-color: #D3D3D3; color: black; padding: 5px; font-weight: bold; font-size: 14px;")
        tab2 = QLabel(self.setup_screen.bowling_team_combo.currentText())
        tab2.setStyleSheet("background-color: #2E7D32; color: white; padding: 5px; font-weight: bold; font-size: 14px;")
        tabs_lay.addWidget(tab1, 1)
        tabs_lay.addWidget(tab2, 1)
        self.right_layout.addLayout(tabs_lay)
        
        self.batting_table = QLabel("")
        self.batting_table.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.batting_table.setStyleSheet("border: none; margin-top: 10px; color: black; background-color: white;")
        self.right_layout.addWidget(self.batting_table)
        
        self.bowling_table = QLabel("")
        self.bowling_table.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.bowling_table.setStyleSheet("border: none; margin-top: 20px; color: black; background-color: white;")
        self.right_layout.addWidget(self.bowling_table)
        
        # ================= COMBINE =================
        main_split.addWidget(left_panel, 5)
        
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setFrameShadow(QFrame.Sunken)
        main_split.addWidget(sep)
        
        main_split.addWidget(right_panel, 5)
        self.scoring_layout.addLayout(main_split)
        
    def end_innings(self):
        reply = QMessageBox.question(self, "Confirm", "End current innings and start new?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.state["innings"] = 1
            self.state["target"] = None
            self.setup_screen.refresh_data()
            self.stacked.setCurrentIndex(0)
            
    def end_first_innings(self):
        target = self.state["runs"] + 1
        QMessageBox.information(self, "Innings Over", f"Innings 1 has ended!\nTarget for next team: {target}")
        
        self.state["innings"] = 2
        self.state["target"] = target
        
        self.state["innings_1_stats"] = {
            "runs": self.state["runs"],
            "wickets": self.state["wickets"],
            "overs_completed": self.state["overs_completed"],
            "balls_this_over": self.state["balls_this_over"]
        }
        
        # Swap combo boxes in setup screen automatically!
        idx1 = self.setup_screen.batting_team_combo.currentIndex()
        idx2 = self.setup_screen.bowling_team_combo.currentIndex()
        self.setup_screen.batting_team_combo.setCurrentIndex(idx2)
        self.setup_screen.bowling_team_combo.setCurrentIndex(idx1)
        
        self.stacked.setCurrentIndex(0)
        
    def end_match(self):
        target = self.state.get("target")
        if target and self.state["runs"] >= target:
             msg = f"{self.setup_screen.batting_team_combo.currentText()} won the match!"
        elif target and self.state["runs"] == target - 1:
             msg = "Match Tied!"
        else:
             msg = f"{self.setup_screen.bowling_team_combo.currentText()} won the match!"
             
        QMessageBox.information(self, "Match Over", msg)
        self.state["innings"] = 1
        self.state["target"] = None
        self.setup_screen.refresh_data()
        self.stacked.setCurrentIndex(0)
            
    def swap_batsmen(self):
        self.state["striker"], self.state["non_striker"] = self.state["non_striker"], self.state["striker"]
        self.update_ui()
        
    def check_over_end(self):
        if self.state["balls_this_over"] >= self.state["balls_per_over"]:
            if self.state.get("bowler_runs_this_over", 0) == 0:
                self.state["bowler"]["maidens"] = self.state["bowler"].get("maidens", 0) + 1
            self.state["bowler_runs_this_over"] = 0
            
            # End of over
            self.state["overs_completed"] += 1
            self.state["balls_this_over"] = 0
            self.state["past_overs"].append({
                "bowler": self.state["bowler"]["name"],
                "runs": self.state["bowler"]["runs"],
                "wickets": self.state["bowler"]["wickets"],
                "balls": list(self.state["this_over"])
            })
            self.state["this_over"] = []
            self.state["previous_bowler"] = self.state["bowler"]["name"]
            
            self.update_ui()
            
            # Check innings limits
            if self.state["overs_completed"] >= self.state["max_overs"]:
                if self.state.get("innings", 1) == 1:
                    self.end_first_innings()
                else:
                    self.end_match()
                return
            
            # Prompt for new bowler
            dlg = NewOverDialog(self.state["previous_bowler"], self.state.get("bowling_team_id"), self)
            if dlg.exec():
                new_b = dlg.bowler_combo.currentText()
                if "bowler_stats" not in self.state:
                    self.state["bowler_stats"] = {}
                if new_b in self.state["bowler_stats"]:
                    self.state["bowler"] = self.state["bowler_stats"][new_b].copy()
                else:
                    self.state["bowler"] = {"name": new_b, "runs": 0, "overs": 0.0, "wickets": 0, "maidens": 0}
            self.swap_batsmen() # Swap at end of over
            self.update_ui()

    def save_state_for_undo(self):
        self.history_stack.append(copy.deepcopy(self.state))
        
    def undo(self):
        if not self.history_stack:
            QMessageBox.information(self, "Undo", "No previous actions to undo!")
            return
        self.state = self.history_stack.pop()
        self.update_ui()
        
    def process_delivery(self, label, team_runs, bat_runs, bowl_runs, valid_ball, physical_runs, is_wide):
        self.save_state_for_undo()
        
        self.state["runs"] += team_runs
        self.state["bowler"]["runs"] += bowl_runs
        self.state.setdefault("bowler_runs_this_over", 0)
        self.state["bowler_runs_this_over"] += bowl_runs
        
        self.state["striker"]["runs"] += bat_runs
        
        if bat_runs == 4: self.state["striker"]["4s"] = self.state["striker"].get("4s", 0) + 1
        if bat_runs == 6: self.state["striker"]["6s"] = self.state["striker"].get("6s", 0) + 1
        
        if not is_wide:
            self.state["striker"]["balls"] += 1
            
        for k in ["wd", "nb", "b", "lb"]:
            self.state.setdefault("extras", {}).setdefault(k, 0)
            
        if is_wide: 
            self.state["extras"]["wd"] += 1
            if physical_runs > 0:
                self.state["extras"]["b"] += physical_runs
        elif "Nb" in label: 
            self.state["extras"]["nb"] += 1
            if "LB" in label:
                self.state["extras"]["lb"] += physical_runs
            elif "B" in label:
                self.state["extras"]["b"] += physical_runs
        else:
            if "LB" in label:
                self.state["extras"]["lb"] += physical_runs
            elif "B" in label:
                self.state["extras"]["b"] += physical_runs
            
        self.state["this_over"].append(label)
        
        if valid_ball:
            self.state["balls_this_over"] += 1
            b_over_balls = int(self.state["bowler"]["overs"] * 10) % 10 + 1
            b_over_full = int(self.state["bowler"]["overs"])
            if b_over_balls == self.state.get("balls_per_over", 6):
                self.state["bowler"]["overs"] = float(b_over_full + 1)
            else:
                self.state["bowler"]["overs"] = float(f"{b_over_full}.{b_over_balls}")
                
        if physical_runs % 2 != 0:
            self.swap_batsmen()
            
        self.update_ui()
        self.check_over_end()
        
        if self.state.get("innings") == 2 and self.state.get("target") and self.state["runs"] >= self.state["target"]:
            self.end_match()

    def show_wd_menu(self):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: white; color: black; font-size: 16px; font-weight: bold; } QMenu::item { padding: 10px 20px; } QMenu::item:selected { background-color: #0d6efd; color: white; }")
        options = [
            ("Wd", 1), ("1+wd", 2), ("2+wd", 3), ("3+wd", 4),
            ("4+wd", 5), ("5+wd", 6), ("6+wd", 7),
        ]
        for text, runs in options:
            action = menu.addAction(text)
            action.triggered.connect(lambda checked=False, t=text, r=runs: self.process_delivery(t, r, 0, r, False, r-1, True))
        menu.exec(self.wd_btn.mapToGlobal(self.wd_btn.rect().bottomLeft()))

    def show_lb_menu(self):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: white; color: black; font-size: 16px; font-weight: bold; } QMenu::item { padding: 10px 20px; } QMenu::item:selected { background-color: #0d6efd; color: white; }")
        for i in range(1, 8):
            t = f"{i}LB"
            action = menu.addAction(t)
            action.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r, 0, 0, True, r, False))
        menu.exec(self.lb_btn.mapToGlobal(self.lb_btn.rect().bottomLeft()))

    def show_byes_menu(self):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: white; color: black; font-size: 16px; font-weight: bold; } QMenu::item { padding: 10px 20px; } QMenu::item:selected { background-color: #0d6efd; color: white; }")
        for i in range(1, 8):
            t = f"{i}B"
            action = menu.addAction(t)
            action.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r, 0, 0, True, r, False))
        menu.exec(self.byes_btn.mapToGlobal(self.byes_btn.rect().bottomLeft()))

    def show_nb_menu(self):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: white; color: black; font-size: 16px; font-weight: bold; } QMenu::item { padding: 5px 20px; } QMenu::item:selected { background-color: #0d6efd; color: white; }")
        
        a = menu.addAction("NB")
        a.triggered.connect(lambda checked=False: self.process_delivery("NB", 1, 0, 1, False, 0, False))
        
        for i in [1, 2, 3, 4, 6]:
            t = f"{i}+NB"
            a = menu.addAction(t)
            a.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r+1, r, r+1, False, r, False))
            
        lb_menu = menu.addMenu("LB")
        for i in range(1, 8):
            t = f"{i}L NB"
            a = lb_menu.addAction(t)
            a.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r+1, 0, 1, False, r, False))
            
        bye_menu = menu.addMenu("bye")
        for i in range(1, 8):
            t = f"{i}B NB"
            a = bye_menu.addAction(t)
            a.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r+1, 0, 1, False, r, False))
            
        more_menu = menu.addMenu("4567")
        for i in range(4, 11):
            t = f"{i} NB"
            a = more_menu.addAction(t)
            a.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r+1, r, r+1, False, r, False))

        menu.exec(self.nb_btn.mapToGlobal(self.nb_btn.rect().bottomLeft()))

    def show_more_runs_menu(self):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: white; color: black; font-size: 16px; font-weight: bold; } QMenu::item { padding: 10px 20px; } QMenu::item:selected { background-color: #0d6efd; color: white; }")
        
        for i in [5, 7, 8, 9, 10]:
            t = str(i)
            action = menu.addAction(t)
            action.triggered.connect(lambda checked=False, text=t, r=i: self.process_delivery(text, r, r, r, True, r, False))
            
        menu.exec(self.more_runs_btn.mapToGlobal(self.more_runs_btn.rect().bottomLeft()))

    def score_wicket(self):
        batting_id = self.setup_screen.batting_team_combo.currentData()
        bowling_id = self.state.get("bowling_team_id")
        
        striker_name = self.state["striker"]["name"]
        non_striker_name = self.state["non_striker"]["name"]
        out_batsmen = self.state.get("out_batsmen", [])
        
        dlg = WicketDialog(striker_name, non_striker_name, out_batsmen, batting_id, bowling_id, self)
        if not dlg.exec():
            return
            
        self.save_state_for_undo()
            
        method = dlg.method_combo.currentText()
        new_bat_name = dlg.new_batsman_combo.currentText()
        
        self.state["wickets"] += 1
        
        team_runs = 0
        bat_runs = 0
        bowl_runs = 0
        is_wide = False
        is_nb = False
        out_batsman = striker_name
        physical_runs = 0
        
        label = "W"
        
        if method == "Stumped" or method == "Hit Wicket":
            is_wide = dlg.is_wide_cb.isChecked()
            if is_wide:
                label = "Wd + W"
            
        elif method == "Run Out":
            out_batsman = dlg.ro_batsman_combo.currentText()
            physical_runs = int(dlg.ro_runs_combo.currentText())
            ext = dlg.ro_extra_combo.currentText()
            ill = dlg.ro_illegal_combo.currentText()
            
            if ill == "Wide":
                is_wide = True
            elif ill == "No Ball":
                is_nb = True
                
            team_runs += physical_runs
            if ext == "None":
                if is_wide:
                    bowl_runs += physical_runs
                else:
                    bat_runs += physical_runs
                    bowl_runs += physical_runs
                
            if physical_runs == 0:
                if is_wide:
                    label = "Wd + W"
                elif is_nb:
                    label = "Nb + W"
            else:
                if is_wide:
                    label = f"Wd + {physical_runs} + W"
                elif is_nb:
                    if ext == "Byes":
                        label = f"Nb + {physical_runs}B + W"
                    elif ext == "Leg Byes":
                        label = f"Nb + {physical_runs}LB + W"
                    else:
                        label = f"Nb + {physical_runs} + W"
                else:
                    if ext == "Byes":
                        label = f"{physical_runs}B + W"
                    elif ext == "Leg Byes":
                        label = f"{physical_runs}LB + W"
                    else:
                        label = f"{physical_runs} + W"
                
        if is_wide or is_nb:
            team_runs += 1
            bowl_runs += 1
                
        valid_ball = not (is_wide or is_nb)
        
        self.state["runs"] += team_runs
        self.state["bowler"]["runs"] += bowl_runs
        self.state.setdefault("bowler_runs_this_over", 0)
        self.state["bowler_runs_this_over"] += bowl_runs
        
        # The striker ALWAYS gets the runs and balls faced
        self.state["striker"]["runs"] += bat_runs
        if bat_runs == 4: self.state["striker"]["4s"] = self.state["striker"].get("4s", 0) + 1
        if bat_runs == 6: self.state["striker"]["6s"] = self.state["striker"].get("6s", 0) + 1
        
        if not is_wide:
            self.state["striker"]["balls"] += 1
            
        for k in ["wd", "nb", "b", "lb"]:
            self.state.setdefault("extras", {}).setdefault(k, 0)
            
        if is_wide:
            self.state["extras"]["wd"] += 1
            if physical_runs > 0:
                self.state["extras"]["b"] += physical_runs
        elif "Nb" in label:
            self.state["extras"]["nb"] += 1
            if "LB" in label:
                self.state["extras"]["lb"] += physical_runs
            elif "B" in label:
                self.state["extras"]["b"] += physical_runs
        else:
            if "LB" in label:
                self.state["extras"]["lb"] += physical_runs
            elif "B" in label:
                self.state["extras"]["b"] += physical_runs
                
        if method != "Run Out":
            self.state["bowler"]["wickets"] += 1
            
        self.state["this_over"].append(label)
        
        # Track out batsman
        if "out_batsmen" not in self.state:
            self.state["out_batsmen"] = []
        self.state["out_batsmen"].append(out_batsman)
        
        if out_batsman == striker_name:
            self.state["striker"]["status"] = f"out ({method})"
            self.state.setdefault("batsmen_stats", {})[out_batsman] = self.state["striker"].copy()
            self.state["striker"] = {"name": new_bat_name, "runs": 0, "balls": 0, "4s": 0, "6s": 0, "status": "not out"}
            self.state["batsmen_stats"][new_bat_name] = self.state["striker"].copy()
        else:
            self.state["non_striker"]["status"] = f"out ({method})"
            self.state.setdefault("batsmen_stats", {})[out_batsman] = self.state["non_striker"].copy()
            self.state["non_striker"] = {"name": new_bat_name, "runs": 0, "balls": 0, "4s": 0, "6s": 0, "status": "not out"}
            self.state["batsmen_stats"][new_bat_name] = self.state["non_striker"].copy()
            
        if valid_ball:
            self.state["balls_this_over"] += 1
            b_over_balls = int(self.state["bowler"]["overs"] * 10) % 10 + 1
            b_over_full = int(self.state["bowler"]["overs"])
            if b_over_balls == self.state.get("balls_per_over", 6):
                self.state["bowler"]["overs"] = float(b_over_full + 1)
            else:
                self.state["bowler"]["overs"] = float(f"{b_over_full}.{b_over_balls}")
                
        if physical_runs % 2 != 0:
            self.swap_batsmen()
            
        self.update_ui()
        
        # Check all out
        if self.state["wickets"] >= 10:
            if self.state.get("innings", 1) == 1:
                self.end_first_innings()
            else:
                self.end_match()
            return
            
        self.check_over_end()
        
        if self.state.get("innings") == 2 and self.state.get("target") and self.state["runs"] >= self.state["target"]:
            self.end_match()

    def update_ui(self):
        s = self.state
        
        innings = s.get("innings", 1)
        score_str = f"{s['runs']}/{s['wickets']}"
        over_str = f"({s['overs_completed']}.{s['balls_this_over']})"
        
        if innings == 1:
            self.lbl_team1_score.setText(score_str)
            self.lbl_team1_overs.setText(over_str)
        else:
            self.lbl_team2_score.setText(score_str)
            self.lbl_team2_overs.setText(over_str)
        
        bpo = s.get("balls_per_over", 6)
        total_balls = s["overs_completed"] * bpo + s["balls_this_over"]
        rr = (s["runs"] / total_balls * bpo) if total_balls > 0 else 0
        self.lbl_rr.setText(f"RR: {rr:.2f}")
        
        if s.get("target"):
            self.lbl_target.setText(f"Target: {s['target']}")
            runs_needed = s["target"] - s["runs"]
            balls_rem = (s.get("max_overs", 20) * bpo) - total_balls
            if balls_rem > 0:
                rrr = (runs_needed / balls_rem) * bpo
            else:
                rrr = 0
            self.lbl_rrr.setText(f"RRR: {rrr:.2f}")
        else:
            self.lbl_target.setText("Target: -")
            self.lbl_rrr.setText("RRR: -")
            
        self.lbl_striker_name.setText(f"{s['striker']['name']} *")
        self.lbl_striker_score.setText(f"{s['striker']['runs']} ({s['striker']['balls']})")
        
        self.lbl_non_striker_name.setText(s['non_striker']['name'])
        self.lbl_non_striker_score.setText(f"{s['non_striker']['runs']} ({s['non_striker']['balls']})")
        
        self.lbl_bowler_name.setText(s['bowler']['name'])
        self.lbl_bowler_score.setText(f"{s['bowler']['runs']}-{s['bowler']['wickets']} ({s['bowler']['overs']})")
        
        extras = s.get("extras", {"wd": 0, "nb": 0, "b": 0, "lb": 0})
        total_extras = sum(extras.values())
        self.lbl_extras_detail.setText(f"{total_extras} (W {extras.get('wd',0)}, NB {extras.get('nb',0)}, B {extras.get('b',0)}, LB {extras.get('lb',0)})")
        
        target_boxes = max(s["balls_per_over"], len(s["this_over"]))
        
        while len(self.over_boxes) < target_boxes:
            box = QLabel("")
            box.setMinimumSize(50, 50)
            box.setFixedHeight(50)
            box.setAlignment(Qt.AlignCenter)
            self.over_boxes.append(box)
            self.mid_layout.insertWidget(self.mid_layout.count() - 1, box)
            
        for i, box in enumerate(self.over_boxes):
            if i < target_boxes:
                box.show()
                if i < len(s["this_over"]):
                    val = s["this_over"][i]
                    box.setText(val)
                    if "W" in val:
                        box.setStyleSheet("border: 2px solid black; border-radius: 8px; font-size: 18px; font-weight: bold; background: #dc3545; color: white; padding: 0 10px;")
                    else:
                        box.setStyleSheet("border: 2px solid black; color: black; border-radius: 8px; font-size: 18px; font-weight: bold; background: white; padding: 0 10px;")
                else:
                    box.setText("")
                    box.setStyleSheet("border: 1px solid gray; color: black; border-radius: 8px; background: transparent;")
            else:
                box.hide()
                
        # History
        for i in reversed(range(self.history_layout.count())): 
            self.history_layout.itemAt(i).widget().setParent(None)
            
        for i, over in enumerate(s["past_overs"]):
            row = QHBoxLayout()
            lbl = QLabel(f"{i+1}st {over['bowler']}  {over['runs']} - {over['wickets']}")
            lbl.setStyleSheet("font-weight: bold; background: #ED7D31; padding: 5px; color: white; border-radius: 4px;")
            row.addWidget(lbl)
            for ball in over["balls"]:
                b_lbl = QLabel(ball)
                b_lbl.setMinimumSize(30, 30)
                b_lbl.setFixedHeight(30)
                b_lbl.setAlignment(Qt.AlignCenter)
                if "W" in ball:
                    b_lbl.setStyleSheet("border: 1px solid black; color: white; border-radius: 4px; font-weight: bold; background: #dc3545; padding: 0 5px;")
                else:
                    b_lbl.setStyleSheet("border: 1px solid black; color: black; border-radius: 4px; font-weight: bold; background: white; padding: 0 5px;")
                row.addWidget(b_lbl)
            row.addStretch()
            w = QWidget()
            w.setLayout(row)
            self.history_layout.addWidget(w)
                
        # Sync active players to full list
        s_name = s["striker"]["name"]
        ns_name = s["non_striker"]["name"]
        b_name = s["bowler"]["name"]
        
        if "batsmen_stats" in s:
            s["batsmen_stats"][s_name] = s["striker"].copy()
            s["batsmen_stats"][ns_name] = s["non_striker"].copy()
            s["bowler_stats"][b_name] = s["bowler"].copy()
            
        bat_rows = ""
        for name, p in s.get("batsmen_stats", {}).items():
            sr = (p["runs"] / p["balls"] * 100) if p.get("balls", 0) > 0 else 0
            status = p.get("status", "not out")
            color = "gray" if "out" in status and status != "not out" else "black"
            bold = "<b>" if status == "not out" else ""
            bold_end = "</b>" if status == "not out" else ""
            
            bat_rows += f"""
            <tr>
                <td align="left" style='color: {color};'>{bold}{name}{bold_end}<br/><span style="color: gray; font-size: 11px;">{status}</span></td>
                <td align="center" style='color: {color};'>{p['runs']}</td>
                <td align="center" style='color: {color};'>{p.get('balls', 0)}</td>
                <td align="center" style='color: {color};'>{p.get('4s', 0)}</td>
                <td align="center" style='color: {color};'>{p.get('6s', 0)}</td>
                <td align="center" style='color: {color};'>{sr:.2f}</td>
            </tr>
            """
            
        bat_html = f"""
        <table width="100%" style="font-size: 14px;" cellspacing="0" cellpadding="5">
            <tr style="border-bottom: 1px solid gray; background-color: #f0f0f0;">
                <th align="left">Batting</th><th align="center">R</th><th align="center">B</th><th align="center">4s</th><th align="center">6s</th><th align="center">S/R</th>
            </tr>
            {bat_rows}
        </table>
        """
        self.batting_table.setText(bat_html)
        
        bowl_rows = ""
        bpo = s.get("balls_per_over", 6)
        for name, p in s.get("bowler_stats", {}).items():
            overs = p.get('overs', 0.0)
            b_full = int(overs)
            b_rem = int(round((overs - b_full)*10))
            total_balls = b_full * bpo + b_rem
            econ = (p['runs'] / total_balls * bpo) if total_balls > 0 else 0
            
            bowl_rows += f"""
            <tr>
                <td align="left"><b>{name}</b></td>
                <td align="center">{overs:.1f}</td>
                <td align="center">{p.get('maidens', 0)}</td>
                <td align="center">{p['runs']}</td>
                <td align="center">{p['wickets']}</td>
                <td align="center">{econ:.2f}</td>
            </tr>
            """
            
        bowl_html = f"""
        <table width="100%" style="font-size: 14px;" cellspacing="0" cellpadding="5">
            <tr style="border-bottom: 1px solid gray; background-color: #f0f0f0;">
                <th align="left">Bowling</th><th align="center">O</th><th align="center">M</th><th align="center">R</th><th align="center">W</th><th align="center">Econ</th>
            </tr>
            {bowl_rows}
        </table>
        """
        self.bowling_table.setText(bowl_html)
        
        ws_state = {
            "runs": s["runs"],
            "wickets": s["wickets"],
            "overs_completed": s["overs_completed"],
            "balls_this_over": s["balls_this_over"],
            "current_batters": [s["striker"]["name"], s["non_striker"]["name"]],
            "bowler": s["bowler"]["name"],
            "this_over": s["this_over"],
            "theme_color": s.get("theme_color", "#1A2B3C")
        }
        ws_manager.send_state(ws_state)
