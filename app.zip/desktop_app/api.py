import requests
import os

BASE_URL = "http://127.0.0.1:8000/api"

def create_team(name, theme_color, logo_path=None):
    url = f"{BASE_URL}/teams/"
    data = {
        "name": name,
        "theme_color": theme_color,
    }
    files = {}
    if logo_path and os.path.exists(logo_path):
        files["logo"] = open(logo_path, "rb")

    response = requests.post(url, data=data, files=files if files else None)
    
    if "logo" in files:
        files["logo"].close()
        
    response.raise_for_status()
    return response.json()

def create_player(first_name, last_name, jersey_number, role, team_id, image_path=None):
    url = f"{BASE_URL}/players/"
    data = {
        "first_name": first_name,
        "last_name": last_name,
        "jersey_number": jersey_number,
        "role": role,
        "team": team_id,
    }
    files = {}
    if image_path and os.path.exists(image_path):
        files["image"] = open(image_path, "rb")

    response = requests.post(url, data=data, files=files if files else None)
    
    if "image" in files:
        files["image"].close()
        
    response.raise_for_status()
    return response.json()

def get_teams():
    url = f"{BASE_URL}/teams/"
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()
    return data.get('results', data) if isinstance(data, dict) else data

def get_players(team_id=None):
    url = f"{BASE_URL}/players/"
    params = {}
    if team_id:
        params["team"] = team_id
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()
    return data.get('results', data) if isinstance(data, dict) else data
