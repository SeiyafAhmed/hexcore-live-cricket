import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget
from ui.pre_match_setup import PreMatchSetup
from ui.live_scoring import LiveScoringTab
from ui.settings_tab import SettingsTab
from ws_client import ws_manager

class CricketScorerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cricket Scorer Desktop App")
        self.resize(800, 600)
        
        self.tabs = QTabWidget()
        
        # Pre-Match Setup Tab
        self.pre_match_setup = PreMatchSetup()
        self.tabs.addTab(self.pre_match_setup, "Pre-Match Setup")
        
        # Live Scoring Tab
        self.live_scoring = LiveScoringTab()
        self.tabs.addTab(self.live_scoring, "Live Scoring")
        
        # Settings Tab
        self.settings_tab = SettingsTab()
        self.tabs.addTab(self.settings_tab, "Settings")
        
        self.setCentralWidget(self.tabs)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        
        # Refresh teams initially when app starts
        self.pre_match_setup.refresh_teams()
        
        # Start WebSocket Manager
        ws_manager.start()

    def on_tab_changed(self, index):
        if index == 1:
            self.live_scoring.setup_screen.refresh_data()

    def closeEvent(self, event):
        ws_manager.stop()
        ws_manager.wait()
        super().closeEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Modern stylesheet for a better look
    app.setStyleSheet("""
        QMainWindow {
            background-color: #f0f2f5;
        }
        QPushButton {
            background-color: #0d6efd;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #0b5ed7;
        }
        QLineEdit, QSpinBox, QComboBox {
            padding: 6px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
        QListWidget {
            border: 1px solid #ced4da;
            border-radius: 4px;
            padding: 4px;
        }
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ced4da;
            border-radius: 6px;
            margin-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px 0 5px;
        }
        QDialog, QMessageBox {
            background-color: white;
            color: black;
        }
        QMessageBox QLabel, QDialog QLabel {
            color: black;
        }
    """)
    
    window = CricketScorerApp()
    window.show()
    sys.exit(app.exec())
